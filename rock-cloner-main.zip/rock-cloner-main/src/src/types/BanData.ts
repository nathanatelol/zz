import { Snowflake } from 'discord.js-selfbot-v13';

export interface BanData {
    id: Snowflake;
    reason: string;
}
